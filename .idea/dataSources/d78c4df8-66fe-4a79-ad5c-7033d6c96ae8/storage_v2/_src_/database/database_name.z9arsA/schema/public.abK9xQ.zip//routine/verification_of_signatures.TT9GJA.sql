create function verification_of_signatures(bigint) returns void
    language plpgsql
as
$$
BEGIN
        if((SELECT count(*) from "Signatures" where parameters_id = $1 and is_subscribed = false) = 0) then
            update "Parameters"
            set status = true
            where parameters_id = $1;
            Raise notice 'successfully updated';
        else
             raise exception '% not enough signatures', $1;
        end if;

    end;
$$;

alter function verification_of_signatures(bigint) owner to postgres;

