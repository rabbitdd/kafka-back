create function generate_schedule() returns void
    language plpgsql
as
$$
declare
    time_startt time;
    time_finissh time;
    time_of_work interval;
    index   int = 1;
    pool_times time[] = '{10:00:00, 10:30:00, 11:00:00, 11:30:00, 12:00:00, 12:30:00, 13:00:00, 13:30:00, 14:00:00, 14:30:00, ' ||
                        '15:00:00, 15:30:00, 16:00:00, 16:30:00, 17:00:00, 17:30:00, 18:00:00, 18:30:00, 19:00:00, 19:30:00, 20:00:00, 20:30:00, ' ||
                        '21:00:00, 21:30:00}';
    BEGIN
        time_of_work = random() * (interval '7 hours' + interval '59 minutes') + interval '1 minute';
        index = floor(random() * array_length(pool_times, 1) + 1)::int;
        time_startt = pool_times[index];
        if(time_startt + time_of_work > '22:00:00' or time_startt + time_of_work < '10:00:00') then
            time_finissh = '22:00:00';
        else
            time_finissh = time_startt + time_of_work;
        end if;
        insert into "Schedule" (time_start, time_finish) values (time_startt, time_finissh);
    end;
$$;

alter function generate_schedule() owner to postgres;

