create function generate_type_of_document_benefits() returns void
    language plpgsql
as
$$
declare
        type_doc    varchar[] = '{Почетный гражданин страны, Инвалидность, Ветеран боевых действий}';
        index       bigint = 0;
        new_name    varchar;
        p_id        bigint[];
        index_p     bigint;
        some_ind_1 bigint = 1;
        some_char_1 varchar = '1';
        some_ind_2 bigint = 1;
        some_char_2 varchar = '1';
        some_ind_3 bigint = 1;
        some_char_3 varchar = '1';
        length int = 0;
    begin
        length = round(random() * 100);
        for i in 1..length
        loop
            index = floor(random() * array_length(type_doc, 1) + 1)::int;
            if index = 1 then
                new_name = type_doc[index] || ' ' || some_char_1;
                some_ind_1 = some_ind_1 + 1;
                some_char_1 = some_ind_1::varchar;
            else if index = 2 then
               new_name = type_doc[index] || ' ' || some_char_2;
                some_ind_2 = some_ind_2 + 1;
                some_char_2 = some_ind_2::varchar;
            else
                new_name = type_doc[index] || ' ' || some_char_3;
                some_ind_3 = some_ind_3 + 1;
                some_char_3 = some_ind_3::varchar;
            end if;
            end if;
            p_id = ARRAY(select privileges_id from "Privileges")::int[];
            index_p = floor(random() * array_length(p_id, 1) + 1)::int;
            index_p = p_id[index_p];
            insert into "TypeOfDocument" (name, privileges_id, instance_id)
            values (new_name, index_p, 1);
        end loop;
    end;
$$;

alter function generate_type_of_document_benefits() owner to postgres;

