create function official_some_function() returns void
    language plpgsql
as
$$
declare
        officialId bigint[];
        rnd bigint;
        parametersId bigint[];
        length  bigint;
        flag    bool;
    begin
        parametersId = ARRAY(select parameters_id from "Parameters");
        length = (array_length(parametersId, 1))::bigint;
        for i in 1..length
        loop
            officialId = ARRAY(select official_id from "Parameters"
                        join "Document" on "Parameters".parameters_id = "Document".parameters_id
                        join "TypeOfDocument" on "Document".type_of_document_id = "TypeOfDocument".type_of_document_id
                        join "Official" on "Official".instance_id = "TypeOfDocument".instance_id
                        where "Parameters".parameters_id = parametersId[i]);
            rnd = floor(random() * 3 + 1)::bigint;
            for j in 1..rnd
                loop
                    flag = random() > 0.5;
                    insert into "Signatures" (official_id, parameters_id, is_subscribed)
                    values (officialId[j], parametersId[i], flag);
                end loop;
        end loop;
    end
$$;

alter function official_some_function() owner to postgres;

