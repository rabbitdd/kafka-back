create function put_in_queue(bigint, bigint) returns bigint
    language plpgsql
as
$$
DECLARE
        prior bigint;
        plac bigint;
        u_id bigint;
        of_id bigint;
    BEGIN
        u_id = $1;
        of_id = $2;
        prior = calculate_priority(u_id);
        plac = (select min(place) from "Queue" where prior > priority and official_id = of_id);
        if(plac is not null) then
            UPDATE "Queue"
            SET place = place + 1
            where place >= plac and official_id = of_id;
            Insert INTO "Queue" (official_id, user_id, place, priority)  values(of_id, u_id, plac, prior);
            RAISE NOTICE 'queue updated';
        else
            plac = (select max(place) from "Queue" where official_id = of_id);
            if(plac is not null) then
                plac = plac + 1;
            else
                plac = 1;
            end if;
            Insert INTO "Queue" (official_id, user_id, place, priority) values(of_id, u_id, plac, prior);
            RAISE NOTICE 'queue updated';
        end if;
        return plac;
end;
$$;

alter function put_in_queue(bigint, bigint) owner to postgres;

