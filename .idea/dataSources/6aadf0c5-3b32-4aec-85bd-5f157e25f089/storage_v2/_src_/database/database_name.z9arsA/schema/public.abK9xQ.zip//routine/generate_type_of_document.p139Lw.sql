create function generate_type_of_document() returns void
    language plpgsql
as
$$
declare
        type_doc    varchar[] = '{Справка разрешения, Договор, Подписной лист, Медецинская справка, Юридическая справка}';
        index       bigint = 0;
        new_name    varchar;
        inst_id     bigint[];
        length int = 0;
        length2 bigint = 0;
        some_ind_1 bigint = 1;
        some_char_1 varchar = '1';
        some_ind_2 bigint = 1;
        some_char_2 varchar = '1';
        some_ind_3 bigint = 1;
        some_char_3 varchar = '1';
        some_ind_4 bigint = 1;
        some_char_4 varchar = '1';
        some_ind_5 bigint = 1;
        some_char_5 varchar = '1';
    begin
        inst_id = ARRAY(select instance_id from "Instance")::bigint[];
        length2 = (array_length(inst_id, 1))::bigint;
        for i in 1..length2
        loop
            length = round(random() * 4) + 1;
            for j in 1..length
            loop
                index = floor(random() * array_length(type_doc, 1) + 1)::int;
                if index = 1 then
                    new_name = type_doc[index] || ' ' || some_char_1;
                    some_ind_1 = some_ind_1 + 1;
                    some_char_1 = some_ind_1::varchar;
                else if index = 2 then
                    new_name = type_doc[index] || ' ' || some_char_2;
                    some_ind_2 = some_ind_2 + 1;
                    some_char_2 = some_ind_2::varchar;
                else if index = 3 then
                    new_name = type_doc[index] || ' ' || some_char_3;
                    some_ind_3 = some_ind_3 + 1;
                    some_char_3 = some_ind_3::varchar;
                else if index = 4 then
                    new_name = type_doc[index] || ' ' || some_char_4;
                    some_ind_4 = some_ind_4 + 1;
                    some_char_4 = some_ind_4::varchar;
                else
                    new_name = type_doc[index] || ' ' || some_char_5;
                    some_ind_5 = some_ind_5 + 1;
                    some_char_5 = some_ind_5::varchar;
                end if;
                end if;
                end if;
                end if;
                insert into "TypeOfDocument" (name, privileges_id, instance_id)
                values (new_name, 1, inst_id[i]);
            end loop;
        end loop;
    end;
$$;

alter function generate_type_of_document() owner to postgres;

