create function check_office_hours() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.time_finish - interval '8 hours' > NEW.time_start then
            raise exception '% the number of working hours cannot exceed 8', NEW;
        ELSE
            return NEW;
        end if;
    end;
$$;

alter function check_office_hours() owner to postgres;

