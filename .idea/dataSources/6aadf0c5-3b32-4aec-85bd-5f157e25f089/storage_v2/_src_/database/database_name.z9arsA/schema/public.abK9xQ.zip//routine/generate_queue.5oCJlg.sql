create function generate_queue() returns void
    language plpgsql
as
$$
declare
            pull_users bigint[];
            plac bigint;
            pull_parameters bigint[];
            pull_officcials bigint [];
            lenght bigint;
            lenght2 bigint;
            lenght3 bigint;
        begin
            pull_users = ARRAY(select user_id from "users");
            lenght =  (array_length(pull_users, 1))::bigint;
            for i in 1..lenght
                loop
                     pull_parameters = ARRAY(select "Parameters".parameters_id from "Parameters" join "Document" D on "Parameters".parameters_id = D.parameters_id
                        where user_id = pull_users[i]);
                     lenght2 = (array_length(pull_parameters, 1))::bigint;
                     for j in 1 ..lenght2
                        loop
                             pull_officcials = ARRAY(SELECT official_id from "Signatures" where parameters_id = pull_parameters[j] and is_subscribed = false);
                             lenght3 = (array_length(pull_officcials, 1))::bigint;
                             if(lenght3 is null) then
                                 Update "Parameters"
                                 set status = true
                                 where parameters_id = pull_parameters[j];
                            else
                                for k in 1..lenght3
                                    loop
                                        plac = (select put_in_queue(pull_users[i], pull_officcials[k]));
                                    end loop;
                             end if;
                         end loop;

                end loop;
        end;

$$;

alter function generate_queue() owner to postgres;

