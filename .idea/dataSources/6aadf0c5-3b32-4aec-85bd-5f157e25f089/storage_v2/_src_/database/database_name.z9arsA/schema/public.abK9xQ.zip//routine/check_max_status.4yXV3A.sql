create function check_max_status() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (SELECT max_quantity from "Checker" where checker_id = NEW.checker_id) < (SELECT count(*) from "Status"
            where checker_id = NEW.checker_id and is_valid = false) + 1 then
            raise exception '% search of the checked references', NEW.checker_id;
        ELSE
            return NEW;
        end if;
    end;
$$;

alter function check_max_status() owner to postgres;

