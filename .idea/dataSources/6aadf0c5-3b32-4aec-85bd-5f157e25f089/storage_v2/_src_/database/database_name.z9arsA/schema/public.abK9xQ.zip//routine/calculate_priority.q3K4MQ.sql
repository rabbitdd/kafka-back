create function calculate_priority(bigint) returns bigint
    language plpgsql
as
$$
declare
        pr bigint;
    begin
        pr = (Select SUM(priv.priority) from "Document" docs
                join "TypeOfDocument" typed on typed.type_of_document_id = docs.type_of_document_id
                join "Privileges" priv on priv.privileges_id = typed.privileges_id
                where docs.user_id = $1)::bigint;
        return pr;
    end;
$$;

alter function calculate_priority(bigint) owner to postgres;

