create function generate_document_basic() returns void
    language plpgsql
as
$$
declare
        type_pull_basic bigint[];
        type_pull_priveleges bigint[];
        basic bigint;
        priv bigint;
        us bigint;
        date_of_i1 date;
        date_of_i2 date;
        valid date;
        name_d          bigint;
        pull_names      varchar[] = '{Москва, Самара, Владивосток, Владикавказ, Париж, Вашингтон, Санкт-Петербург, Киев, Брест,' ||
                                    'Белград, Казань}';
        pull_user bigint[];
        som bigint;
        som2 bigint;
        som3 bigint;
        length bigint;
    begin
       type_pull_basic = ARRAY(select type_of_document_id from "TypeOfDocument" where type_of_document_id < 4)::bigint[];
       type_pull_priveleges = ARRAY(select type_of_document_id from "TypeOfDocument" where privileges_id > 1)::bigint[];
       pull_user = ARRAY(select user_id from "users")::bigint[];
       length = (array_length(pull_user, 1))::bigint;
       for i in 1..length
            loop
                som = round(random()) + 1;
                som2 = floor(random() * array_length(type_pull_basic, 1) + 1)::bigint;
                som3  = floor(random() * array_length(type_pull_priveleges, 1) + 1)::bigint;
                date_of_i1 = '2014-01-01'::date + random() * interval '8 years';
                date_of_i2 = '2014-01-01'::date + random() * interval '60 years';
                name_d = floor(random() * array_length(pull_names, 1) + 1)::bigint;
                valid = now()::date + random() * interval '10 years' + interval '1 year';
                us = pull_user[i];
                basic = type_pull_basic[som2];
                priv = type_pull_priveleges[som3];
                insert into "Document" (type_of_document_id, user_id, date_of_issue, validity, issued_by_whom, parameters_id)
                values (basic, us, date_of_i1, valid, pull_names[name_d], null);
                if(som = 1) then
                    insert into "Document" (type_of_document_id, user_id, date_of_issue, validity, issued_by_whom, parameters_id)
                values (priv, us, date_of_i2, null, pull_names[name_d], null);
                end if;
            end loop;
    end;
$$;

alter function generate_document_basic() owner to postgres;

