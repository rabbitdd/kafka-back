create function generate_status() returns void
    language plpgsql
as
$$
DECLARE
        pull_checker bigint[];
        pull_param bigint[];
        lenght bigint;
        lenght2 bigint;
        inst bigint;
        ch_id bigint;
        flag boolean;
    Begin
        pull_param = ARRAY(select parameters_id from "parameters" where status = true);
        lenght = (array_length(pull_param, 1))::bigint;
        for i in 1..lenght
            loop
                inst = (select instance_id from "document"
                    join "typeOfDocument" TOD on "document".type_of_document_id = TOD.type_of_document_id where parameters_id = pull_param[i])::bigint;
                pull_checker = ARRAY(select checker_id from "checker" join "prosecutor" P on "checker".prosecutor_id = P.prosecutor_id where instance_id = inst);
                lenght2 = (array_length(pull_checker, 1))::bigint;
                ch_id = 0;
                for j in 1..lenght2
                    loop
                        if((select count(*) from "status" where is_valid = false and checker_id = pull_checker[j]) < (select max_quantity from "checker" where checker_id = pull_checker[j])) then
                            ch_id = pull_checker[j];
                        end if;
                    end loop;
                if(NOT(ch_id = 0)) then
                    flag = random() > 0.5;
                    insert into "status" (is_valid, parameter_id, checker_id) VALUES (flag, pull_param[i], ch_id);
                end if;
            end loop;
    end;
$$;

alter function generate_status() owner to postgres;

