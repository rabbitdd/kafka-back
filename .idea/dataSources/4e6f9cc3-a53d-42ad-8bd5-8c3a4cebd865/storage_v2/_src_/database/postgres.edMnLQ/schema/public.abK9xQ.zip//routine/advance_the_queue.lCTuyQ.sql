create function advance_the_queue(bigint) returns boolean
    language plpgsql
as
$$
BEGIN
        Delete from "queue"
            where place = 1;
        UPDATE "queue"
        SET place = place - 1
        where place > 0 and official_id = $1;
        RAISE NOTICE 'queue moved';
        return true;
    end;
$$;

alter function advance_the_queue(bigint) owner to postgres;

