create function generate_privileges() returns void
    language plpgsql
as
$$
declare
    sale_possible_new  int = 0;
    priority_new       bigint = 0;
    coefficient_sign_new     bigint = 0;
begin
    sale_possible_new = round(random() * 100);
    priority_new = round(random() * 1000);
    coefficient_sign_new = round(random() * 1000);
    INSERT INTO "privileges" (sale, priority, coeff_sign)
    VALUES (sale_possible_new, priority_new, coefficient_sign_new);
end;
$$;

alter function generate_privileges() owner to postgres;

