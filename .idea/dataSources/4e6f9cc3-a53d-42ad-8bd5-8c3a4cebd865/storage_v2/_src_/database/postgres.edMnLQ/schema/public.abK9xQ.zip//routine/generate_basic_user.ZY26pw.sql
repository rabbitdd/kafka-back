create function generate_basic_user() returns void
    language plpgsql
as
$$
declare
        name_u           varchar(15);
        pull_names      varchar[] = '{Михаил, Марк, Мирон, Андрей, Павел, Анатолий, Николай, Виктор, Кирилл, Богдан, Никита, Владимир, ' ||
                                        'Парфен, Карл}';
        surname_u         varchar(30);
        pull_surnames   varchar[] = '{Козлов, Мишанин, Николаев, Попов, Троцкий, Маркс, Капронов, Ксенофонтов, Иванов, Лазарев, ' ||
                                        'Пересвятов, Краснов, Серов, Голубков, Перенов, Датагрипов, Хохлов, Серов, Салов, Пис, Работов, Роботов, ' ||
                                        'Умнов, Поляков, Коков, Мореходов, Перескопов}';

        pull_names_w    varchar[] = '{Елена, Мария, Светлана, Михалина, Юлия, Анастасия, Елизавета, Софья, Соня, София, Анна, Анет, Ким}';
        pull_surnames_w varchar[] = '{Камова, Пулева, Булева, Комарова, Тамова, Тарханова, Мирославова, Лютикова, Козлова, Мишанина, ' ||
                                        'Лампова, Постгресова, Механова, Плеханова, Сын Зю, Перефракторава, Рефакторова, Мониторова, Усатова, Нью Белосова, Найкова, Таймстампова}';
        sex int;
        mon decimal;
        time_res timestamp;
        index_n int;
        index_s int;
    BEGIN
	for i in 1..2000
	loop
        mon = round(random() * 10000);
        time_res = now() + random()*interval '1 years' + interval '3 hours' + interval '1 hours';
        sex = round(random()) + 1;
        if(sex = 1) then
            index_n = floor(random() * array_length(pull_names, 1) + 1)::int;
            index_s = floor(random() * array_length(pull_surnames, 1) + 1)::int;
            name_u = pull_names[index_n];
            surname_u = pull_surnames[index_s];
        else
            index_n = floor(random() * array_length(pull_names_w, 1) + 1)::int;
            index_s = floor(random() * array_length(pull_surnames_w, 1) + 1)::int;
            name_u = pull_names_w[index_n];
            surname_u = pull_surnames_w[index_s];
        end if;
        insert into "users" (login, password, name, surname, money, time_result, role, active, instance_id)  values
                     (i, i, name_u, surname_u, mon, time_res, 'user', true,  1);
	end loop;
    end;
$$;

alter function generate_basic_user() owner to postgres;

