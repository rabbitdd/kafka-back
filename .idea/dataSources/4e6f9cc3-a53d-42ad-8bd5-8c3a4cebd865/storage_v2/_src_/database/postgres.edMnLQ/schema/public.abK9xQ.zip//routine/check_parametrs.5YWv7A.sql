create function check_parametrs() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.type_of_document_id > 3 and NEW.parameters_id is null then
            raise exception '% reference parameter cannot be null', NEW;
        ELSE
            if new.type_of_document_id <= 3 and New.parameters_id is not null then
                raise exception '% document cannot have parameters', NEW;
            Else
                return NEW;
            end if;
        end if;
    end;
$$;

alter function check_parametrs() owner to postgres;

