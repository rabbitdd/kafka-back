create function generate_privileges_default() returns void
    language plpgsql
as
$$
declare
    sale_possible_new  int = 0;
    priority_new       bigint = 0;
    coefficient_sign_new     bigint = 0;
begin
    INSERT INTO "privileges" (sale, priority, coeff_sign)
    VALUES (sale_possible_new, priority_new, coefficient_sign_new);
end;
$$;

alter function generate_privileges_default() owner to postgres;

