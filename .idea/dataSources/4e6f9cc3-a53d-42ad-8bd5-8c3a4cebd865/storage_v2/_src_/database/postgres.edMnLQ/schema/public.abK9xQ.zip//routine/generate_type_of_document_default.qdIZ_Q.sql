create function generate_type_of_document_default() returns void
    language plpgsql
as
$$
begin
        insert into "typeOfDocument" (name, privileges_id, instance_id) values ('Пасспорт', 1, 1);
        insert into "typeOfDocument" (name, privileges_id, instance_id) values ('Свидетельство о рождении', 1, 1);
        insert into "typeOfDocument" (name, privileges_id, instance_id) values ('Права на вождение автомобиля', 1, 1);
        insert into "typeOfDocument" (name, privileges_id, instance_id) values ('Справка с места работы', 1, 1);
    end;
$$;

alter function generate_type_of_document_default() owner to postgres;

