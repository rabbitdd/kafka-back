create function check_docs_type() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (Select count(*) from "document"
             where user_id = NEW.user_id and type_of_document_id = NEW.type_of_document_id) > 0 THEN
             raise exception '% such a document already exists', NEW.user_id;
         Else
             return NEW;
         end if;
    end;
$$;

alter function check_docs_type() owner to postgres;

