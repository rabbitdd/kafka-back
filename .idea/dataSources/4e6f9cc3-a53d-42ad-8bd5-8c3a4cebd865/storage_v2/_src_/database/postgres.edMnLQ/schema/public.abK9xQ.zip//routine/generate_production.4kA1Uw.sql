create function generate_production() returns void
    language plpgsql
as
$$
declare
        pull_bk bigint[];
        quanlity bigint;
        q bigint;
        type_of_doc_pull bigint[];
        costt decimal;
        time_int interval;
        length bigint;
        type_id bigint;
    BEGIN
        pull_bk = ARRAY(select bookkeeping_id from "bookkeeping")::bigint[];
        type_of_doc_pull = ARRAY(select type_of_document_id from "typeOfDocument" where (privileges_id = 1
                                and name != 'Пасспорт' and name != 'Свидетельство о рождении' and name != 'Права на вождение автомобиля'
                                 and name != 'Справка с места работы'))::bigint[];
        length = (array_length(pull_bk, 1))::bigint;
        for i in 1..length
            loop
                q = (select quantity from "bookkeeping" where bookkeeping_id = pull_bk[i])::bigint;
                for j in 1..q
                    loop
                        quanlity = round(random() * 100);
                        time_int = random() * interval '1 days' + interval '10 minutes';
                        costt = round(random() * 1000);
                        type_id = floor(random() * array_length(type_of_doc_pull, 1) + 1)::bigint;
                        if((select count(*) from "production" where (bookkeeping_id = pull_bk[i] and type_of_document_id = type_of_doc_pull[type_id])) = 0) then
                            insert into "production" (bookkeeping_id, quantity, type_of_document_id, cost, time) VALUES (pull_bk[i], quanlity, type_of_doc_pull[type_id], costt, time_int);
                        end if;
                    end loop;
            end loop;
    end;
$$;

alter function generate_production() owner to postgres;

