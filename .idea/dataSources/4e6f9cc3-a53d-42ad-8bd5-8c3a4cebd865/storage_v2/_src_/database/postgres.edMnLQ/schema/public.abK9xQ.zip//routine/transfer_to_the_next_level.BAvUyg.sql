create function transfer_to_the_next_level(bigint) returns boolean
    language plpgsql
as
$$
DECLARE
        pull_parameters bigint;
        pull_status bigint;
    begin
        pull_parameters = (select count(*) from "parameters"
            join "document" D on "parameters".parameters_id = D.parameters_id
            join "users" U on U.user_id = D.user_id
            join "typeOfDocument" TOD on D.type_of_document_id = TOD.type_of_document_id
            where D.user_id = $1 and TOD.instance_id = (Select instance_id from "users" where "users".user_id = $1) and "parameters".status = false);
        if(pull_parameters = 0) then
            pull_status = (select count(*) from "parameters"
            join "document" D on "parameters".parameters_id = D.parameters_id
            join "users" U on U.user_id = D.user_id
            join "typeOfDocument" TOD on D.type_of_document_id = TOD.type_of_document_id
            join "status" S on "parameters".parameters_id = S.parameter_id
            where D.user_id = $1 and TOD.instance_id = (Select instance_id from "users" where "users".user_id = $1) and S.is_valid = false);
            if(pull_status = 0) then
                raise notice 'you can transfer to the next instance';
                return true;
            else
                raise notice 'not all references have been checked yet';
                return false;
            end if;
        else
            raise notice 'not all certificates are signed';
            return false;
        end if;
    end;

$$;

alter function transfer_to_the_next_level(bigint) owner to postgres;

