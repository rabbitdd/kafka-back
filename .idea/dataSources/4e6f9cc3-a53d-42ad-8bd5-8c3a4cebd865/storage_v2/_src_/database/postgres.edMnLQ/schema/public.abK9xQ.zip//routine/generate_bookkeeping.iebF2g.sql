create function generate_bookkeeping() returns void
    language plpgsql
as
$$
declare
        qual bigint;
        pull_sch bigint[];
        index_sch bigint;
        sch_id bigint;
    begin
        pull_sch = ARRAY(select schedule_id from "schedule")::bigint[];
        qual = floor(random() * 10) + 1;
        index_sch = floor(random() * array_length(pull_sch, 1) + 1)::bigint;
        sch_id = pull_sch[index_sch];
        insert into "bookkeeping" (quantity, schedule_id) VALUES (qual, sch_id);
    end;
$$;

alter function generate_bookkeeping() owner to postgres;

