create function official_some_function() returns void
    language plpgsql
as
$$
declare
        officialId bigint[];
        rnd bigint;
        parametersId bigint[];
        length  bigint;
        flag    bool;
    begin
        parametersId = ARRAY(select parameters_id from "parameters");
        length = (array_length(parametersId, 1))::bigint;
        for i in 1..length
        loop
            officialId = ARRAY(select official_id from "parameters"
                        join "document" on "parameters".parameters_id = "document".parameters_id
                        join "typeOfDocument" on "document".type_of_document_id = "typeOfDocument".type_of_document_id
                        join "official" on "official".instance_id = "typeOfDocument".instance_id
                        where "parameters".parameters_id = parametersId[i]);
            rnd = floor(random() * 3 + 1)::bigint;
            for j in 1..rnd
                loop
                    flag = random() > 0.5;
                    insert into "signatures" (official_id, parameters_id, is_subscribed)
                    values (officialId[j], parametersId[i], flag);
                end loop;
        end loop;
    end
$$;

alter function official_some_function() owner to postgres;

