create function check_time_result() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.time_result <= (SELECT NOW() + interval '3 hours') THEN
        raise exception '% this time cannot be used as the result time', NEW.time_result;
    ELSE
        return NEW;
    END IF;
end;
$$;

alter function check_time_result() owner to postgres;

