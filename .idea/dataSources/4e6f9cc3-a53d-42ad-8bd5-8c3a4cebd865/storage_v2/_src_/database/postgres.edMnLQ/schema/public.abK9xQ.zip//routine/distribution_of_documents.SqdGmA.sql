create function distribution_of_documents() returns void
    language plpgsql
as
$$
declare
        instance_array  bigint;
        instance_random_index   bigint;
        instance_random bigint;
        user_array_id  bigint[];
        type_of_documentId bigint[];
        length  bigint;
        length2 bigint;
        date_of_i1 date;
        parameter   bigint;
        valid date;
        name_d  bigint;
    begin
        instance_array = (select count(*) from "instance");
        user_array_id = ARRAY(select user_id from "users");
        length = (array_length(user_array_id, 1))::bigint;
        for i in 1..length
            loop
                instance_random_index = floor(random() * instance_array + 1)::bigint;
                instance_random = instance_random_index;
                type_of_documentId = ARRAY(select type_of_document_id from "typeOfDocument" where instance_id = instance_random and type_of_document_id > 4 and privileges_id = 1);
                length2 = (array_length(type_of_documentId, 1))::bigint;
                update "users" set instance_id = instance_random where user_id = user_array_id[i];
                for j in 1..length2
                    loop
                    date_of_i1 = '2014-01-01'::date + random() * interval '8 years';
                    insert into "parameters" (status) values (false);
                    parameter = (select max(parameters_id) from "parameters");
                    insert into "document" (type_of_document_id,
                                            user_id,
                                            date_of_issue, validity, issued_by_whom, parameters_id)
                    values (type_of_documentId[j], user_array_id[i], date_of_i1, null, 'Замок', parameter);
                    end loop;
            end loop;
    end
$$;

alter function distribution_of_documents() owner to postgres;

