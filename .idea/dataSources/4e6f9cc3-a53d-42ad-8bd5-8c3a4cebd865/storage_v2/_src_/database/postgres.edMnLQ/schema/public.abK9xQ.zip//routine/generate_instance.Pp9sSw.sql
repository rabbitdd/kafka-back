create function generate_instance() returns void
    language plpgsql
as
$$
declare
        brands_of_instance  varchar[] = '{Староста, Отделение управления деревни, Психиатрическая лечебница, Полиция, Братство,' ||
                                        ' Регулятор, Поликлиника, Почта, Отделение управления замка, Юридическая контора, Церковь}';
        index               int = 0;
        new_name            varchar;
    begin
        index = floor(random() * array_length(brands_of_instance, 1) + 1)::int;
        new_name = brands_of_instance[index];
        insert into "instance" (name) values (new_name);
    end;
$$;

alter function generate_instance() owner to postgres;

