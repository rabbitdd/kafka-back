create function generate_prosecutor() returns void
    language plpgsql
as
$$
declare
        inst_id  bigint[];
        pull_sch bigint[];
        sch_id bigint;
        length bigint;
        index_sch bigint;
    BEGIN
        inst_id = ARRAY(select instance_id from "instance")::bigint[];
        pull_sch = ARRAY(select schedule_id from "schedule")::bigint[];
        length = (array_length(inst_id, 1))::bigint;
        for i in 1..length
            loop
                index_sch = floor(random() * array_length(pull_sch, 1) + 1)::bigint;
                sch_id = pull_sch[index_sch];
                insert into "prosecutor" (instance_id, schedule_id) VALUES (inst_id[i], sch_id);
            end loop;
    end;
$$;

alter function generate_prosecutor() owner to postgres;

