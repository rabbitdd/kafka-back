create function add_for_review(bigint) returns void
    language plpgsql
as
$$
declare
            flag boolean[];
            inst bigint;
            pull_checker bigint[];
            lenght2 bigint;
            ch_id bigint;
            col bigint;
            status bigint;
        begin
            col = (SELECT count(*) from "parameters" where parameters_id = $1)::bigint;
            if(col = 0) then
                raise exception 'there is no parameter %', $1;
            else
                flag = ARRAY(SELECT "parameters".status from "parameters" where parameters_id = $1);
                if(NOT flag[1]) then
                    raise exception '% update the status of signatures', $1;
                else
                    status = (select count(*) from "status" join "parameters" P on P.parameters_id = "status".parameter_id where parameters_id = $1)::bigint;
                    if(status = 0) then
                        inst = (select instance_id from "document"
                            join "typeOfDocument" TOD on "document".type_of_document_id = TOD.type_of_document_id where parameters_id = $1)::bigint;
                        pull_checker = ARRAY(select checker_id from "checker" join "prosecutor" P on "Checker".prosecutor_id = P.prosecutor_id where instance_id = inst);
                        lenght2 = (array_length(pull_checker, 1))::bigint;
                        ch_id = 0;
                        for j in 1..lenght2
                            loop
                                if((select count(*) from "status" where is_valid = false and checker_id = pull_checker[j]) < (select max_quantity from "checker" where checker_id = pull_checker[j])) then
                                    ch_id = pull_checker[j];
                                end if;
                        end loop;
                        if(NOT(ch_id = 0)) then
                            insert into "status" (is_valid, parameter_id, checker_id) VALUES (false, $1, ch_id);
                            raise notice 'successfully added for verification';
                        else
                            raise exception 'there are no available employees at this number %', inst;
                        end if;
                    else
                        raise exception '% already under review', $1;
                    end if;
                end if;
            end if;
        end;
$$;

alter function add_for_review(bigint) owner to postgres;

