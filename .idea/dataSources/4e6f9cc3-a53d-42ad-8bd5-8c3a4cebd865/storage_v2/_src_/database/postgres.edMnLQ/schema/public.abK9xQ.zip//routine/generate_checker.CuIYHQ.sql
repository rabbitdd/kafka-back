create function generate_checker() returns void
    language plpgsql
as
$$
declare
        time_i interval;
        qual bigint;
        process_id bigint[];
        length bigint;
        length2 int;
    BEGIN
        process_id = ARRAY(select prosecutor_id from "prosecutor")::bigint[];
        length = (array_length(process_id, 1))::bigint;
        for i in 1..length
            loop
                length2 = round(random() * 9) + 1;
                for j in 1..length2
                    loop
                        qual = floor(random() * 10) + 1;
                        time_i = random() * interval '23 hours' + interval '1 hours';
                        insert into "checker" (time, max_quantity, prosecutor_id) values (time_i, qual, process_id[i]);
                    end loop;
            end loop;
    end;
$$;

alter function generate_checker() owner to postgres;

